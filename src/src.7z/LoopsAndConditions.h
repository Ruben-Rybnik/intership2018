#pragma once

namespace gris
{
  /** \brief This functions combines the content of sections A1 to A3 of the book "Einstieg in C++" by Arnold Willemer

    See section A ("C++ f�r Hektiker", pages 427-440)
  */
  void runLoopsAndConditions();
}
