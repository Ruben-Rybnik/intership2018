
namespace gris
{
	enum EnImageTypes
	{
		enChess,
		enStripes,
		enBlack
	};

	int getInteger(int lowerBond, int upperBound);
	
	int getIndentation(int upperBound, int lowerBound);
}