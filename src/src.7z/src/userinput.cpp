#include <iostream>

namespace gris
{
	int getInteger(int lowerBound, int upperBound)
	{
		std::cout << "Bitte geben Sie eine Zahl von " << lowerBound << " bis " << upperBound << " ein. \n";
		int badInput = true;
		int integer;
		while (badInput)
		{
			std::cin >> integer;
			if (integer >= lowerBound && integer <= upperBound)
			{
				badInput = false;
				break;
			}
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<int>::max(), '\n');
		};
		return integer;
	}


	
}