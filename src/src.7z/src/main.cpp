#include "LoopsAndConditions.h"
#include "PointerAndReferences.h"
//#include "SphereSourceExample.h"

#include <exception>
#include <vector>
#include <iostream>

int main(int argc, char** argv)
{
	for (int i(0); i<argc; ++i)
		std::cout << argv[i] << std::endl;

  //gris::runSphereSourceExample();
  //gris::runLoopsAndConditions();
  //try
  //{
	 // //std::vector<double> vec(std::numeric_limits<size_t>::max());

	 // double  d  = 5.0;
	 // double* pd = &d;

	 // std::cout << "value:   " << d << std::endl;
	 // std::cout << "address: " << pd << std::endl;
	 // std::cout << "value:   " << *pd << std::endl;
  //}
  //catch (std::exception& e)
  //{
	 // std::cout << e.what() << std::endl;
  //}
  gris::runPointerAndReferences();
  return 0;
}