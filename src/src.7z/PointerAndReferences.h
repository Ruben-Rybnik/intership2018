#pragma once

namespace gris
{
  /** \brief This function plays with pointers, references and functions.
      Compare with A4, pages 440-448
  */
  void runPointerAndReferences();
}
