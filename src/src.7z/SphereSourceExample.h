#pragma once
namespace gris
{
  /** \brief A Visualization of a sphere
  */
  void runSphereSourceExample();
}